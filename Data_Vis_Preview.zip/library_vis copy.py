import streamlit as st
import matplotlib.pyplot as plt
import pandas as pd
#import numpy as np
#from bokeh.plotting import figure, show, output_notebook 

st.title("Is the Public Library Dead?")
st.subheader("By Abigail Mirot")

st.write("""My research question is “Are public libraries dying or evolving?”. The advent of the internet has forced public libraries to choose whether or not to adapt to this new world or perish with the old ways. Overwhelmingly, libraries have chosen to change in order to meet the needs of the communities they serve. Libraries that, at one time, only contained physical materials, have filled themselves with computers and e-books. 

But are these changes enough to save the public library? 

I will be using data from the Public Libraries Survey (PLS), a survey that has been conducted annually since 1988 by the Institute of Museum and Library Services. The Institute surveys over 9,000 public libraries on an array of topics from population size to gross income. I want to specifically look at five criteria from surveys from 1997 to 2022. I’ve chosen these specific years because I wanted to show the amount of electronic materials that libraries contained pre-internet versus the modern-day numbers. I hope that this twenty-five year difference displays the dramatic shift towards providing non-physical materials.

Note: Prior to 1997, the survey didn’t record the amount of electronic materials in circulation. In addition, the most recent survey available was conducted in 2022.

The five criteria I’ve chosen to compare are the number of employees working at public libraries, the number of electronic materials in circulation, the total circulation, the total annual library visits, and the libraries’ total incomes. 
""")

legend = {'Legend': ['null']}
df = pd.DataFrame(legend)
print(df)

PLS_97 = pd.read_csv("PLS_97.csv", encoding='latin-1')
PLS_97["Year"] = 1997
PLS_02 = pd.read_csv("PLS_02.csv", encoding='latin-1')
PLS_02["Year"] = 2002
PLS_07 = pd.read_csv("PLS_07.csv", encoding='latin-1')
PLS_07["Year"] = 2007
PLS_12 = pd.read_csv("PLS_12.csv", encoding='latin-1')
PLS_12["Year"] = 2012
PLS_17 = pd.read_csv("PLS_17.csv", encoding='latin-1')
PLS_17["Year"] = 2017
PLS_22 = pd.read_csv("PLS_22.csv", encoding='latin-1')
PLS_22["Year"] = 2022

st.dataframe(PLS_97)
st.write(""""Explain the dataset""")

combined_data = pd.concat([PLS_97, PLS_02, PLS_07, PLS_12, PLS_17, PLS_22])

inc_plot = combined_data.groupby('Year')['TOTINCM'].mean()
st.bar_chart(inc_plot)
st.write("""Total income bar chart""")

fig, ax = plt.subplots()
y1 = combined_data.groupby('Year')['TOTOPEXP'].mean()
y2= combined_data.groupby('Year')['ELMATEXP'].mean()
ax.bar(y1.index, y1.values, color='r')
ax.bar(y2.index, y2.values, bottom=y1, color='b')
ax.set_xticklabels([1997, 2002, 2007, 2012, 2017, 2022])
plt.title("Total Operating Expenditures versus Electronic Material Expenditures")
st.pyplot(fig = fig)




st.write("""This split bar graph displays the amount of the total annual expenditure that is used to maintain and purchase electronic materials.""")

tot_exp_97 = PLS_97.groupby('Year')['TOTOPEXP'].sum()
web_exp_97 = PLS_97.groupby('Year')['ELMATEXP'].sum()
st.write(web_exp_97, tot_exp_97)
# why did you switch to sum > mean?

st.write("""



52,678,573 / 3707126053 compared to 1% in 1997""")

tot_exp = PLS_22.groupby('Year')['TOTOPEXP'].sum()
web_exp = PLS_22.groupby('Year')['ELMATEXP'].sum()
st.write(web_exp, tot_exp)

st.write("""619,233,993 / 14147646846 = approx. 4% of the total annual expenditures for public 
         libraries in 2022 was used towards the purchasing and maintenance of electronic materials. This may not seem like a lot, but when you consider all of the services libraries provide, 
         not to mention the salaries of those employed at libraries, it starts to feel like a much larger chunk of the budget.""") 

#Simple bar chart w/ each year attendance rates
#Take the mean of attendance

attend_plot = combined_data.groupby('Year')['VISITS'].sum()
st.bar_chart(attend_plot)

tot_vis = PLS_22.groupby('Year')['VISITS'].sum()
web_vis = PLS_22.groupby('Year')['WEBVISIT'].sum()
st.write(web_vis, tot_vis)

st.write("""670,948,457 / 1,238,475,493 = approx. 54% more visits to public library websites over entering the physical library space in 2022.
         no crossover between web and normal""")


#__________________________________________________
#Notes
##Percentage of expenditure

#st.bokehchart()

#Simple bar chart showing increase in income (combined local, state, federal)
#Take the mean of each year's income

#Map chart showing varying visit numbers per region (only 2022)
#visits_22 = PLS_22['VISITS']

# x = year y = attendance numbers
#A = year
#B = Attendance

#Make a bar chart showing total
# expenditures w/ a chunk separate bar just for electronic materials 
#.index, .values

#y1 = combined_data.groupby('Year')['TOTOPEXP'].mean()
#y2= combined_data.groupby('Year')['ELMATEXP'].mean()
##total_perc = y2 % y1
#st.bar_chart(total_perc)


